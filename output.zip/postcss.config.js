export default {
  plugins: {
    'postcss-px-to-viewport': {
      viewportWidth: 375,
    },
    tailwindcss: {},
    autoprefixer: {},
  },
};
