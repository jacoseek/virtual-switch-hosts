package com.virtual_switch_hosts.app

class MainActivity : TauriActivity()