<template>
  <router-view />
</template>
<script setup lang="ts">
useGlobalStore().init();
useHostsStore().init();
</script>

<style>
.host_area {
  textarea {
    white-space: pre;
    font-size: 12px;
  }
}
</style>
