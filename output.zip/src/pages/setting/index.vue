<template>
  <div class="p-4">
    <app-header>
      <template #left>
        <app-side-menu />
      </template>
      <template #right>
        <app-locale-switch />
        <app-theme-switch />
      </template>
    </app-header>
    <var-space direction="column" size="large">
      <var-select :placeholder="$t('theme')" v-model="theme" :options="themeOptions"> </var-select>
      <var-select :placeholder="$t('language')" v-model="language" :options="langOptions"> </var-select>
    </var-space>
  </div>
</template>
<script lang="ts" setup>
const { theme, language } = storeToRefs(useGlobalStore());
const langOptions = getLangOptions();
const themeOptions = getThemeOptions();
</script>
