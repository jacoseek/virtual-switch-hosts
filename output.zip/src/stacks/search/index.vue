<template>
  <div class="p-3 flex flex-col">
    <var-input v-model="search" autofocus>
      <template #append-icon> <Icon icon="pepicons-print:loop" class="text-2xl"> </Icon> </template>
    </var-input>
    <var-input
      v-model="searchResult"
      textarea
      variant="outlined"
      :placeholder="$t('hosts_result')"
      disabled
      rows="20"
      class="mt-8 text-xxs host_area"
    >
    </var-input>
  </div>
</template>

<script lang="ts" setup>
  import { useHostsStore } from '@/store';

  const search = ref('');
  const { activeHosts } = storeToRefs(useHostsStore());

  const hostsMap = computed(() =>
    activeHosts.value
      .split('\n')
      .filter((line) => line.trim() !== '' && !line.trim().startsWith('#')) // 过滤空行和#开头的行
      .map(
        (line) =>
          line
            .trim() // 去除首尾空格
            .split('#')[0] // 去除行内注释
            .trim(), // 去除行内注释后的多余空格
      ),
  );

  const searchResult = computed(() => hostsMap.value.filter((line) => line.toLowerCase().includes(search.value.toLowerCase())).join('\n'));
</script>
<style lang="scss"></style>
