import { StyleVars, Themes } from '@varlet/ui';
import { usePreferredColorScheme } from '@vueuse/core';

export enum ThemeType {
  Auto,
  Light,
  Dark,
  Unset,
}

export const getThemeOptions = () => {
  const { t } = useI18n();
  return [
    {
      label: t('theme_type.auto'),
      value: ThemeType.Auto,
    },
    {
      label: t('theme_type.light'),
      value: ThemeType.Light,
    },
    {
      label: t('theme_type.dark'),
      value: ThemeType.Dark,
    },
  ];
};

export const changeTheme = (val: ThemeType) => {
  // 清除现有的主题类
  document.documentElement.classList.remove('light', 'dark');

  const applyTheme = (theme: 'dark' | 'light', style: StyleVars | null) => {
    StyleProvider(style);
    document.documentElement.classList.add(theme);
  };

  if (val === ThemeType.Auto) {
    const preferredColor = usePreferredColorScheme();
    if (preferredColor.value === 'dark') {
      applyTheme('dark', Themes.md3Dark);
    } else {
      applyTheme('light', Themes.md3Light);
    }
  } else if (val === ThemeType.Dark) {
    applyTheme('dark', Themes.md3Dark);
  } else if (val === ThemeType.Light) {
    applyTheme('light', Themes.md3Light);
  }
  window.$storage.set('theme', val);
};
